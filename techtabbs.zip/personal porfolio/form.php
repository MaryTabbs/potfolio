<?php
   $name= $_POST ['name'];
   $email= $_POST ['email'];
   $number= $_POST ['number'];
   $message= $_POST ['message'];

   $email_form ='info@techtabbs.com'

   $email_subject='New form submission'
   $email_body =" User Name:$name.\n"
                 " User email:$email.\n"
                 " User number:$number.\n"
                 " User message:$message.\n";

                 $to= "marytabbs@gmail.com"
                 $heaaders=" from:$email_from\r\n";
                 $heaaders="reply-to:$ email\r\n";
                 mail($to,$email_subject, $email_body,$heaaders);

                 header("location: index.html");


   ?>

